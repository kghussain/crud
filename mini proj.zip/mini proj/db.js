let mysql=require('mysql');
let connection=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'Me#13122000',
    database:'ash'
})
module.exports=connection 