ALTER USER 'root'@'localhost' IDENTIFIED WITH 
mysql_native_password BY 'Me#13122000'