CREATE TABLE Employer (
 projectid INT,
 salary VARCHAR(255),
startdate VARCHAR(255),
 enddate VARCHAR(255),
 totaldays VARCHAR(255),
 avgsalary VARCHAR(255)
);