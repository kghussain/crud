const express = require('express');
var dp = require('./db');
var app = express();
app.listen(1200);
dp.connect((err)=>{
 if(err)
 console.log('database connection error'+err);
 else
 console.log('database connected')
})
app.use(express.json());
app.use(require('./modal/user_route'))
// /*const express = require('express');
// const mysql = require('mysql2');

// const app = express();
// const port = 3000;

// // Set up MySQL connection pool


// // PUT method to update a record by id
// app.put('/api/person/:id', (req, res) => {
//   const { name, email, profilePicture, phone, password } = req.body;
//   const id = req.params.id;

//   // Validate input fields here

//   // Update the record in the database
//   pool.query(
//     'UPDATE persons SET name = ?, email = ?, profile_picture = ?, phone = ?, password = ? WHERE id = ?',
//     [name, email, profilePicture, phone, password, id],
//     (err, results, fields) => {
//       if (err) {
//         console.log(err);
//         return res.status(500).json({
//           code: 500,
//           message: 'Internal server error',
//           data: null
//         });
//       }

//       // Check if the record was updated successfully
//       if (results.affectedRows === 0) {
//         return res.status(404).json({
