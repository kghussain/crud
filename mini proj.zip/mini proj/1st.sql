INSERT INTO project (projectname,salary,startdate,enddate,totaldays)
 VALUES (projectname, 100, 13/12/2022,14/01/2023,31);