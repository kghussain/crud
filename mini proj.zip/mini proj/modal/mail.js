const nodemailer=require('nodemailer');
const mailotp=(req,res)=>{
var transporter = nodemailer.createTransport({
    service:'gmail',
    auth: {
      user: 'gulamhussain13122000@gmail.com',
      pass: 'fzrnhdbtfpzgujrc'
    },
    tls:{
      rejectUnauthorized:false
    }
    
  });
  //user_controller
  var mailOptions = {
    from: 'gulamhussain13122000@gmail.com',
    to: 'boythatwtf143@gmail.com',
    to: 'gulamhussain13122000@gmail.com',
    subject: ' Here can see OTP ',
    text:"Hi, we are so happy to having you,  Here can see your OTP : "
  };
  //user_rotuer
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
       
    }
  })
}
function generateOPT(){
  var digits='0123456789';
  let OTP = '';
  for(let i=0;i<4;i++){
    OTP += digits[Math.floor(Math.random()*10)];
  }
  return OTP;
}