const express=require('express')
const router=express.Router();
const projectcontroller=require('./user_controller')
router.post('/ins',projectcontroller.ins);
router.put('/upda',projectcontroller.upda);
router.delete('/del',projectcontroller.del);
router.get('/sel',projectcontroller.sel);
module.exports=router;

