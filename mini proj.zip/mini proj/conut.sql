SELECT COUNT(employer.employestatus)
FROM employer
WHERE employer.employestatus='avtive';